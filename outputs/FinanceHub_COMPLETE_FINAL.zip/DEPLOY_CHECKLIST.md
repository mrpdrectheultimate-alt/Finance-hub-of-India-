# 📋 FinanceHub India — Master Deployment Checklist

> **Version**: 1.0 Final Complete Release  
> **Target Production**: Next.js 14 App Router + Supabase PostgreSQL + Vercel  
> **Master Archive**: `outputs/FinanceHub_COMPLETE_FINAL.zip` (446 files / 15.75 MB)

---

## 🗄️ STEP 1 — Supabase SQL Execution Order (30 Steps)

Run the following SQL scripts in order in the **Supabase SQL Editor**:

### 1. Core Schema
1. `supabase_schema_safe.sql` — Base tables (profiles, tracks, levels, lessons, quizzes)
2. `phase1_critical_fixes.sql` — Security RLS policies & column patches

### 2. Content Tracks & Seeds
3. `seeds/trading_markets_101.sql` — Stock market & trading fundamentals
4. `seeds/crypto_basics.sql` — Bitcoin, Web3 & DeFi curriculum
5. `seeds/corporate_business_basics.sql` — Corporate finance & financial statements
6. `seeds/behavioral_finance.sql` — Psychology of money & decision biases
7. `seeds/forex_basics.sql` — FX market mechanics & currency pairs
8. `seeds/technical_analysis.sql` — Candlesticks, chart patterns & indicators
9. `seeds/personal_finance_intermediate.sql` — Advanced budgeting, SIPs & taxes

### 3. Engine & Analytics
10. `adaptive_learning_engine.sql` — Spaced repetition & mastery algorithm
11. `analytics_views.sql` — Admin analytics & platform activity views

### 4. Video Library
12. `video_library_complete.sql` — 82 structured YouTube educational videos

### 5. Curriculum Expansion (320+ Lessons)
13. `lesson_expansion_phase1.sql` (+57 lessons)
14. `lesson_expansion_phase2.sql` (+52 lessons)
15. `lesson_expansion_phase3.sql` (+50 lessons)
16. `lesson_expansion_phase3_part2.sql` (+6 lessons)

### 6. Quizzes
17. `phase3_quizzes.sql` (184+ interactive quiz questions)

### 7. Notes Schema
18. `digital_notes_schema.sql` — Cloud-synced lesson notes schema

### 8. Feature Migrations
19. `phase1_migration.sql` — User progress & XP extensions
20. `phase2_migration.sql` — Interactive simulator states
21. `phase3_migration.sql` — Certificate generation tables
22. `phase4_migration.sql` — AI Mentor conversation logs
23. `phase5_migration.sql` — Community Q&A forum tables
24. `phase6_migration.sql` — Video library bookmarking

### 9. Advanced Curriculum & Paper Trading
25. `phase7_lessons.sql` (+20 advanced lessons)
26. `phase8_lessons.sql` (+27 career-oriented lessons)
27. `multimedia_trading.sql` — Virtual paper trading portfolio engine

### 10. Gamification & Community
28. `gamification.sql` — XP logs, 20 seeded badges, weekly leaderboards, certificate RPC
29. `community_career.sql` — Community moderation, upvotes, 8 seeded career paths

### 11. Final Reality Audit
30. `phase0_reality_audit.sql` — Run last to verify table integrity & constraint status

---

## 📁 STEP 2 — File Deployment Map

### Root Config Files
- `vercel.json` → `/vercel.json`
- `next.config.js` → `/next.config.js`
- `tailwind.config.ts` → `/tailwind.config.ts`
- `globals.css` → `/app/globals.css`
- `robots.txt` → `/public/robots.txt`
- `manifest.json` → `/public/manifest.json`
- `sw.js` → `/public/sw.js`

### Application Root & Auth
- `layout.tsx` → `/app/layout.tsx`
- `landing_page_clean.tsx` → `/app/page.tsx`
- `login/page.tsx` → `/app/login/page.tsx`
- `signup/page.tsx` → `/app/signup/page.tsx`
- `forgot-password/page.tsx` → `/app/forgot-password/page.tsx`

### Core App Routes
- `dashboard/page.tsx` → `/app/dashboard/page.tsx`
- `explore/page.tsx` → `/app/explore/page.tsx`
- `learn/[slug]/page.tsx` → `/app/learn/[slug]/page.tsx`
- `onboarding/page.tsx` → `/app/onboarding/page.tsx`
- `glossary/page.tsx` → `/app/glossary/page.tsx`
- `review/page.tsx` → `/app/review/page.tsx`
- `leaderboard/page.tsx` → `/app/leaderboard/page.tsx`
- `certificates/page.tsx` → `/app/certificates/page.tsx`
- `pricing/page.tsx` → `/app/pricing/page.tsx`
- `library/page.tsx` → `/app/library/page.tsx`
- `practice/page.tsx` → `/app/practice/page.tsx`
- `profile/page.tsx` → `/app/profile/page.tsx`
- `settings/page.tsx` → `/app/settings/page.tsx`
- `knowledge-map/page.tsx` → `/app/knowledge-map/page.tsx`
- `notes/page.tsx` → `/app/notes/page.tsx`
- `ai-tutor/page.tsx` → `/app/ai-tutor/page.tsx`
- `case-studies/page.tsx` → `/app/case-studies/page.tsx`
- `case-studies/[slug]/page.tsx` → `/app/case-studies/[slug]/page.tsx`
- `verify/[id]/page.tsx` → `/app/verify/[id]/page.tsx`
- `tracks/[slug]/page.tsx` → `/app/tracks/[slug]/page.tsx`

### API & Cron Routes
- `/app/api/auth/callback/route.ts`
- `/app/api/complete-lesson/route.ts`
- `/app/api/search/route.ts`
- `/app/api/payment/razorpay-order/route.ts`
- `/app/api/payment/razorpay-webhook/route.ts`
- `/app/api/stripe-webhook/route.ts`
- `/app/api/email/send-sequence/route.ts`
- `/app/api/generate-certificate/route.ts`
- `/app/api/notes/route.ts`
- `/app/api/mastery/route.ts`
- `/app/api/recommendations/route.ts`
- `/app/api/ai-mentor/route.ts`
- `/app/api/ai-exam-generator/route.ts`
- `/app/api/ai-roadmap-planner/route.ts`
- `/app/api/ai-weakness-detector/route.ts`
- `/app/api/download-lesson-pdf/route.ts`
- `/app/api/cron/reset-ai-limits/route.ts`
- `/app/api/cron/daily-snapshot/route.ts`
- `/app/api/cron/streak-check/route.ts`
- `/app/api/cron/weekly-league/route.ts`

### Global Components
- `Navbar.tsx` → `/components/layout/Navbar.tsx`
- `Footer.tsx` → `/components/layout/Footer.tsx`
- `AppLayout.tsx` → `/components/layout/AppLayout.tsx`

---

## 🔑 STEP 3 — Environment Variables (Vercel)

Configure the following environment variables in **Vercel Project Settings → Environment Variables**:

```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key

ANTHROPIC_API_KEY=sk-ant-api-key

NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_key
STRIPE_SECRET_KEY=sk_live_key
STRIPE_WEBHOOK_SECRET=whsec_key
STRIPE_PRO_MONTHLY_PRICE_ID=price_pro_m
STRIPE_PRO_ANNUAL_PRICE_ID=price_pro_a
STRIPE_EXPERT_MONTHLY_PRICE_ID=price_exp_m

RAZORPAY_KEY_ID=rzp_live_key
RAZORPAY_KEY_SECRET=rzp_secret
RAZORPAY_WEBHOOK_SECRET=rzp_whsec

RESEND_API_KEY=re_key
RESEND_FROM_EMAIL=hello@financehub.in

NEXT_PUBLIC_APP_URL=https://financehub.in
NEXT_PUBLIC_ADMIN_EMAILS=mrpdrecuniverse@gmail.com
INTERNAL_SECRET=your_internal_secret
CRON_SECRET=your_cron_secret
```

---

## 🔗 STEP 4 — External Webhooks Configuration

### 1. Razorpay Dashboard
* **Webhook URL**: `https://financehub.in/api/payment/razorpay-webhook`
* **Active Events**: `payment.captured`, `subscription.activated`, `subscription.cancelled`

### 2. Stripe Dashboard
* **Webhook URL**: `https://financehub.in/api/stripe-webhook`
* **Active Events**: `checkout.session.completed`, `invoice.payment_succeeded`, `invoice.payment_failed`, `customer.subscription.*`

---

## 🧪 STEP 5 — Post-Deploy Verification Query

Run this query in **Supabase SQL Editor** to verify content seeding:

```sql
SELECT 'lessons'    AS category, COUNT(*) AS count FROM lessons WHERE is_published=TRUE
UNION ALL
SELECT 'quizzes',   COUNT(*) FROM quizzes
UNION ALL
SELECT 'videos',    COUNT(*) FROM video_library WHERE is_active=TRUE
UNION ALL
SELECT 'concepts',  COUNT(*) FROM concepts WHERE is_published=TRUE
UNION ALL
SELECT 'glossary',  COUNT(*) FROM glossary WHERE is_published=TRUE
UNION ALL
SELECT 'badges',    COUNT(*) FROM badges WHERE is_active=TRUE
UNION ALL
SELECT 'careers',   COUNT(*) FROM career_paths WHERE is_published=TRUE;
```

### Expected Output Targets:
* **`lessons`**: `320+`
* **`quizzes`**: `50+`
* **`videos`**: `82`
* **`concepts`**: `50`
* **`glossary`**: `35+`
* **`badges`**: `20`
* **`careers`**: `8`
