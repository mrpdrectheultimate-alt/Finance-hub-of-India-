-- ============================================================
-- FinanceHub - Missing Indexes Hotfix
-- Run this in Supabase SQL Editor if verify_supabase_state.sql
-- reports missing indexes.
--
-- Safe behavior:
-- - Uses CREATE INDEX IF NOT EXISTS.
-- - Checks table existence before creating indexes.
-- - Includes compatibility names expected by verify_supabase_state.sql.
-- ============================================================

DO $$
BEGIN
  IF to_regclass('public.quizzes') IS NOT NULL THEN
    CREATE INDEX IF NOT EXISTS idx_quizzes_lesson_id
      ON public.quizzes(lesson_id);
  END IF;

  IF to_regclass('public.quiz_questions') IS NOT NULL THEN
    CREATE INDEX IF NOT EXISTS idx_quiz_questions_quiz_order
      ON public.quiz_questions(quiz_id, order_index);
  END IF;

  IF to_regclass('public.user_progress') IS NOT NULL THEN
    CREATE INDEX IF NOT EXISTS idx_user_progress_user_lesson_base
      ON public.user_progress(user_id, lesson_id);

    CREATE INDEX IF NOT EXISTS idx_user_progress_user_lesson
      ON public.user_progress(user_id, lesson_id);
  END IF;

  IF to_regclass('public.user_badges') IS NOT NULL THEN
    CREATE INDEX IF NOT EXISTS idx_user_badges_user_badge_base
      ON public.user_badges(user_id, badge_id);
  END IF;

  IF to_regclass('public.subscriptions') IS NOT NULL THEN
    CREATE INDEX IF NOT EXISTS idx_subscriptions_user_base
      ON public.subscriptions(user_id);
  END IF;

  IF to_regclass('public.ai_conversations') IS NOT NULL THEN
    CREATE INDEX IF NOT EXISTS idx_ai_conversations_user_base
      ON public.ai_conversations(user_id, created_at DESC);
  END IF;

  IF to_regclass('public.ai_usage_daily') IS NOT NULL THEN
    CREATE INDEX IF NOT EXISTS idx_ai_usage_daily_user_date
      ON public.ai_usage_daily(user_id, date);
  END IF;

  IF to_regclass('public.api_rate_limits') IS NOT NULL THEN
    CREATE INDEX IF NOT EXISTS idx_api_rate_limits_key_reset
      ON public.api_rate_limits(key, reset_at);
  END IF;

  IF to_regclass('public.cron_run_logs') IS NOT NULL THEN
    CREATE INDEX IF NOT EXISTS idx_cron_run_log_job_started
      ON public.cron_run_logs(job_name, ran_at DESC);
  END IF;

  IF to_regclass('public.lessons') IS NOT NULL THEN
    CREATE INDEX IF NOT EXISTS idx_lessons_level_published
      ON public.lessons(level_id, is_published);

    CREATE INDEX IF NOT EXISTS idx_lessons_level_order
      ON public.lessons(level_id, order_index);
  END IF;

  IF to_regclass('public.user_xp_log') IS NOT NULL THEN
    CREATE INDEX IF NOT EXISTS idx_user_xp_log_user_created
      ON public.user_xp_log(user_id, created_at DESC);
  END IF;

  IF to_regclass('public.security_audit_logs') IS NOT NULL THEN
    CREATE INDEX IF NOT EXISTS idx_security_events_user_created
      ON public.security_audit_logs(user_id, created_at DESC);
  END IF;
END $$;

-- Show remaining status for the indexes in the screenshots.
SELECT
  expected.index_name,
  CASE WHEN i.indexname IS NULL THEN 'MISSING' ELSE 'OK' END AS status
FROM (
  VALUES
    ('idx_ai_conversations_user_base'),
    ('idx_ai_usage_daily_user_date'),
    ('idx_api_rate_limits_key_reset'),
    ('idx_cron_run_log_job_started'),
    ('idx_lessons_level_order'),
    ('idx_lessons_level_published'),
    ('idx_quiz_questions_quiz_order'),
    ('idx_quizzes_lesson_id'),
    ('idx_security_events_user_created'),
    ('idx_subscriptions_user_base'),
    ('idx_user_badges_user_badge_base'),
    ('idx_user_progress_user_lesson'),
    ('idx_user_progress_user_lesson_base'),
    ('idx_user_xp_log_user_created')
) AS expected(index_name)
LEFT JOIN pg_indexes i
  ON i.schemaname = 'public'
 AND i.indexname = expected.index_name
ORDER BY expected.index_name;

