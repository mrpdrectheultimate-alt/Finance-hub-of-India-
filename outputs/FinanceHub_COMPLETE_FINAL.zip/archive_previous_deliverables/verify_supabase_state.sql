-- ============================================================
-- FinanceHub - Supabase State Verification
-- Run this in Supabase SQL Editor after applying pending SQL.
-- It checks tables, functions, indexes, admin user, tracks, levels,
-- lesson counts, quiz counts, and duplicate lesson slugs.
-- ============================================================

-- 1) Core table presence
SELECT
  'tables' AS section,
  expected.table_name,
  CASE WHEN t.table_name IS NULL THEN 'MISSING' ELSE 'OK' END AS status
FROM (
  VALUES
    ('profiles'),
    ('tracks'),
    ('levels'),
    ('lessons'),
    ('quizzes'),
    ('quiz_questions'),
    ('user_progress'),
    ('user_xp_log'),
    ('badges'),
    ('user_badges'),
    ('subscriptions'),
    ('ai_conversations'),
    ('admin_users'),
    ('ai_usage_daily'),
    ('api_rate_limits'),
    ('cron_run_logs'),
    ('security_audit_logs')
) AS expected(table_name)
LEFT JOIN information_schema.tables t
  ON t.table_schema = 'public'
 AND t.table_name = expected.table_name
ORDER BY expected.table_name;

-- 2) Critical function presence
SELECT
  'functions' AS section,
  expected.function_name,
  CASE WHEN p.proname IS NULL THEN 'MISSING' ELSE 'OK' END AS status
FROM (
  VALUES
    ('is_admin'),
    ('handle_new_user'),
    ('update_updated_at_column'),
    ('complete_lesson'),
    ('complete_quiz'),
    ('get_ai_usage_today'),
    ('increment_ai_usage'),
    ('check_rate_limit'),
    ('log_cron_run'),
    ('log_security_event')
) AS expected(function_name)
LEFT JOIN pg_proc p
  ON p.proname = expected.function_name
LEFT JOIN pg_namespace n
  ON n.oid = p.pronamespace
 AND n.nspname = 'public'
ORDER BY expected.function_name;

-- 3) Admin user
SELECT
  'admin_users' AS section,
  email,
  created_at
FROM admin_users
ORDER BY created_at DESC;

-- 4) Track and level inventory
SELECT
  'tracks_levels' AS section,
  t.slug AS track_slug,
  t.title AS track_title,
  l.slug AS level_slug,
  l.title AS level_title,
  l.is_free,
  l.order_index
FROM tracks t
JOIN levels l ON l.track_id = t.id
ORDER BY t.order_index, l.order_index;

-- 5) Lesson counts by track and level
SELECT
  'lesson_counts' AS section,
  t.slug AS track_slug,
  l.slug AS level_slug,
  COUNT(ls.id) AS lesson_count,
  COUNT(*) FILTER (WHERE ls.is_free) AS free_lessons,
  COUNT(*) FILTER (WHERE NOT ls.is_free) AS pro_lessons
FROM tracks t
JOIN levels l ON l.track_id = t.id
LEFT JOIN lessons ls ON ls.level_id = l.id
GROUP BY t.slug, l.slug, t.order_index, l.order_index
ORDER BY t.order_index, l.order_index;

-- 6) Expected content check
-- With the current local schema, Phase 3 fallback seeds target:
-- stock-market/beginner, crypto/beginner, corporate-finance/beginner.
SELECT
  'expected_content' AS section,
  expected.track_slug,
  expected.level_slug,
  expected.expected_lessons,
  COUNT(ls.id) AS actual_lessons,
  CASE
    WHEN COUNT(ls.id) >= expected.expected_lessons THEN 'OK'
    ELSE 'MISSING'
  END AS status
FROM (
  VALUES
    ('personal-finance', 'beginner', 10),
    ('stock-market', 'beginner', 15),
    ('crypto', 'beginner', 15),
    ('corporate-finance', 'beginner', 15)
) AS expected(track_slug, level_slug, expected_lessons)
LEFT JOIN tracks t ON t.slug = expected.track_slug
LEFT JOIN levels l ON l.track_id = t.id AND l.slug = expected.level_slug
LEFT JOIN lessons ls ON ls.level_id = l.id
GROUP BY expected.track_slug, expected.level_slug, expected.expected_lessons
ORDER BY expected.track_slug, expected.level_slug;

-- 7) Quiz counts by track and level
SELECT
  'quiz_counts' AS section,
  t.slug AS track_slug,
  l.slug AS level_slug,
  COUNT(DISTINCT q.id) AS quiz_count,
  COUNT(qq.id) AS quiz_question_count
FROM tracks t
JOIN levels l ON l.track_id = t.id
LEFT JOIN lessons ls ON ls.level_id = l.id
LEFT JOIN quizzes q ON q.lesson_id = ls.id
LEFT JOIN quiz_questions qq ON qq.quiz_id = q.id
GROUP BY t.slug, l.slug, t.order_index, l.order_index
ORDER BY t.order_index, l.order_index;

-- 8) Duplicate lesson slugs within the same level
SELECT
  'duplicate_lesson_slugs' AS section,
  t.slug AS track_slug,
  l.slug AS level_slug,
  ls.slug AS lesson_slug,
  COUNT(*) AS duplicate_count
FROM lessons ls
JOIN levels l ON l.id = ls.level_id
JOIN tracks t ON t.id = l.track_id
GROUP BY t.slug, l.slug, ls.slug
HAVING COUNT(*) > 1
ORDER BY duplicate_count DESC, track_slug, level_slug, lesson_slug;

-- 9) Important indexes
SELECT
  'indexes' AS section,
  expected.index_name,
  CASE WHEN i.indexname IS NULL THEN 'MISSING' ELSE 'OK' END AS status
FROM (
  VALUES
    ('idx_lessons_level_order'),
    ('idx_quizzes_lesson_id'),
    ('idx_quiz_questions_quiz_order'),
    ('idx_user_progress_user_lesson_base'),
    ('idx_user_badges_user_badge_base'),
    ('idx_subscriptions_user_base'),
    ('idx_ai_conversations_user_base'),
    ('idx_ai_usage_daily_user_date'),
    ('idx_lessons_level_published'),
    ('idx_user_progress_user_lesson'),
    ('idx_user_xp_log_user_created'),
    ('idx_api_rate_limits_reset_at'),
    ('idx_cron_run_logs_job_ran_at'),
    ('idx_security_audit_logs_user_created')
) AS expected(index_name)
LEFT JOIN pg_indexes i
  ON i.schemaname = 'public'
 AND i.indexname = expected.index_name
ORDER BY expected.index_name;
