# FinanceHub

World-class finance education platform built with Next.js, Supabase, Stripe, Claude, PostHog, Sentry, and Resend.

## Quick Start

1. Copy `.env.example` to `.env.local` and fill all required values.
2. Install dependencies:

```bash
npm install
```

3. Start locally:

```bash
npm run dev
```

4. Run the SQL files in Supabase using the order below.
5. Open `http://localhost:3000`.

## Architecture

- Frontend: Next.js 14 App Router and TypeScript
- Database/Auth: Supabase PostgreSQL and Supabase Auth
- AI: Anthropic Claude
- Payments: Stripe
- Email: Resend
- Product Analytics: PostHog
- Error Tracking: Sentry
- Deployment: Vercel

## Key Features

- 55 lessons across Personal Finance, Trading, Crypto, and Corporate Finance
- Lesson player with quiz flow, XP, badges, and comments
- AI tutor, AI exam generator, roadmap planner, weakness detector, and financial explainer
- Adaptive learning with mastery tracking and spaced repetition
- Daily challenges, weekly missions, seasons, and leaderboards
- SIP, EMI, tax, retirement, startup cash flow, budget, and paper trading simulators
- Career Hub with interview question bank
- Admin panels for lessons, quizzes, users, and analytics

## Phase Breakdown

| Phase | Feature | Main Files |
| --- | --- | --- |
| 1 | Critical learning fixes and atomic RPCs | `sql/phase1_critical_fixes.sql` |
| 2 | Production hardening | `sql/phase2_production_hardening.sql`, `lib/security.ts`, `lib/rate-limit.ts` |
| 3 | Content seeds | `sql/seeds/*.sql` |
| 4 | Adaptive learning engine | `sql/phase4/adaptive_learning_engine.sql` |
| 5 | AI platform upgrade | `app/api/ai-*` |
| 6 | Finance labs | `components/simulators/*` |
| 7 | Gamification | `sql/phase7/gamification.sql`, `components/gamification/*` |
| 8 | Community and Career Hub | `sql/phase8/community_career.sql`, `app/career/page.tsx` |
| 9 | Analytics and launch | `sql/phase9/analytics_scale_launch.sql`, `app/admin/analytics/page.tsx` |

## SQL Run Order

Run these in Supabase SQL Editor:

1. `sql/supabase_schema_safe.sql`
2. Personal Finance seed SQL, if not already included in your base schema
3. `sql/phase1_critical_fixes.sql`
4. `sql/phase2_production_hardening.sql`
5. `sql/seeds/trading_markets_101.sql`
6. `sql/seeds/crypto_basics.sql`
7. `sql/seeds/corporate_business_basics.sql`
8. `sql/phase4/adaptive_learning_engine.sql`
9. `sql/phase7/gamification.sql`
10. `sql/phase8/community_career.sql`
11. `sql/phase9/analytics_scale_launch.sql`

Skip duplicate files:

- `sql/seeds/seed_trading_markets_101.sql`
- `sql/seeds/seed_crypto_basics.sql`
- `sql/phase7/advanced_gamification.sql`

Utility files:

- `sql/admin_users_hotfix.sql`
- `sql/missing_indexes_hotfix.sql`
- `sql/verify_supabase_state.sql`

## Deployment

Before deploying, set all environment variables in Vercel. Then run:

```bash
./DEPLOY.sh
```

After deployment, configure:

- Stripe webhook: `/api/stripe-webhook`
- Supabase signup webhook: `/api/webhook-signup`
- Resend domain authentication
- Supabase Auth redirect URLs
- Sentry and PostHog keys

## Local Build Check

```bash
npm run build
```
