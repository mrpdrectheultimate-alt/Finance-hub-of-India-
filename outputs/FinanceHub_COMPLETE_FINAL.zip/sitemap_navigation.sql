-- ============================================================
-- FinanceHub — Site Map Navigation Entry
-- sitemap_navigation.sql
-- Adds /sitemap-guide to nav + seeds page metadata
-- Run AFTER: supabase_schema_safe.sql
-- ============================================================

-- Add site map page to navigation config (if you have a nav_pages table)
-- If you don't, this just documents the route
INSERT INTO concepts (name, slug, simple_def, full_def, difficulty, track_slugs, tags)
VALUES (
  'FinanceHub Site Map',
  'financehub-site-map',
  'A complete visual guide to every page, feature and learning resource on FinanceHub.',
  'The FinanceHub Site Map at /sitemap-guide shows every section of the platform — Learn (8 tracks, 375+ lessons), Practice (9 simulators), AI Mentor, Library (157+ videos), Community (XP, leagues, certificates), Account, and 15 Career Paths. Each item shows whether it is free, requires Pro, or needs a login. Personalised start paths for 6 learner types: Complete beginner, Aspiring investor, Active trader, Startup founder, Hindi learner, and Exam aspirant.',
  'beginner',
  ARRAY['personal-finance','trading-markets','crypto-defi','corporate-finance','technical-analysis','forex-currency','behavioral-finance'],
  ARRAY['navigation','site-map','guide','beginner','orientation','overview']
) ON CONFLICT (slug) DO NOTHING;

DO $$
BEGIN
  RAISE NOTICE '✅ Site map concept added to knowledge graph';
  RAISE NOTICE '   Deploy: sitemap_guide_page.tsx → app/sitemap-guide/page.tsx';
  RAISE NOTICE '   Add to Navbar under: Explore dropdown or standalone link';
END $$;
