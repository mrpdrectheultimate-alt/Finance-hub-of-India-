"use client";

import React, { useState, useEffect } from "react";
import AppLayout from "@/components/layout/AppLayout";
import { 
  PencilSquareIcon, 
  PlusIcon, 
  MagnifyingGlassIcon, 
  TrashIcon, 
  BookmarkIcon, 
  TagIcon,
  SparklesIcon,
  ArrowDownTrayIcon,
  FolderIcon,
  FunnelIcon,
  CalculatorIcon,
  BoltIcon
} from "@heroicons/react/24/outline";
import { PinIcon } from "lucide-react";
import RoughBookModal from "@/components/notes/RoughBookModal";

interface Note {
  id: string;
  title: string;
  content: string;
  note_type: string;
  tags: string[];
  color: string;
  is_pinned: boolean;
  is_archived: boolean;
  lesson_id?: string;
  lesson_title?: string;
  track_slug?: string;
  track_icon?: string;
  updated_at: string;
}

const COLOR_CONFIG: Record<string, { bg: string; border: string; badge: string; dot: string; text: string }> = {
  yellow: { bg: "bg-amber-500/10", border: "border-amber-500/30", badge: "bg-amber-500/20 text-amber-300", dot: "bg-amber-400", text: "text-amber-200" },
  blue:   { bg: "bg-sky-500/10",   border: "border-sky-500/30",   badge: "bg-sky-500/20 text-sky-300",   dot: "bg-sky-400",   text: "text-sky-200" },
  green:  { bg: "bg-emerald-500/10", border: "border-emerald-500/30", badge: "bg-emerald-500/20 text-emerald-300", dot: "bg-emerald-400", text: "text-emerald-200" },
  pink:   { bg: "bg-rose-500/10",  border: "border-rose-500/30",  badge: "bg-rose-500/20 text-rose-300",  dot: "bg-rose-400",  text: "text-rose-200" },
  purple: { bg: "bg-purple-500/10", border: "border-purple-500/30", badge: "bg-purple-500/20 text-purple-300", dot: "bg-purple-400", text: "text-purple-200" },
  orange: { bg: "bg-orange-500/10", border: "border-orange-500/30", badge: "bg-orange-500/20 text-orange-300", dot: "bg-orange-400", text: "text-orange-200" },
  white:  { bg: "bg-slate-800/40", border: "border-slate-700/60", badge: "bg-slate-700 text-slate-300", dot: "bg-slate-400", text: "text-slate-200" },
};

export default function DigitalNotesPage() {
  const [notes, setNotes] = useState<Note[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [selectedType, setSelectedType] = useState<string>("all");
  const [showPinnedOnly, setShowPinnedOnly] = useState(false);
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);
  const [isRoughBookOpen, setIsRoughBookOpen] = useState(false);
  const [allTags, setAllTags] = useState<string[]>([]);

  const fetchNotes = async () => {
    try {
      setIsLoading(true);
      const res = await fetch("/api/notes");
      const data = await res.json();
      if (data.notes) {
        setNotes(data.notes);
        // Extract all unique tags
        const tagsSet = new Set<string>();
        data.notes.forEach((n: Note) => {
          if (n.tags) n.tags.forEach((t) => tagsSet.add(t));
        });
        setAllTags(Array.from(tagsSet));
        if (data.notes.length > 0 && !selectedNote) {
          setSelectedNote(data.notes[0]);
        }
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchNotes();
  }, []);

  const handleTogglePin = async (note: Note) => {
    try {
      const res = await fetch(`/api/notes/${note.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ is_pinned: !note.is_pinned }),
      });
      if (res.ok) {
        setNotes((prev) =>
          prev.map((n) => (n.id === note.id ? { ...n, is_pinned: !n.is_pinned } : n))
        );
        if (selectedNote?.id === note.id) {
          setSelectedNote({ ...selectedNote, is_pinned: !selectedNote.is_pinned });
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteNote = async (id: string) => {
    if (!confirm("Delete this note permanently?")) return;
    try {
      await fetch(`/api/notes/${id}`, { method: "DELETE" });
      const updated = notes.filter((n) => n.id !== id);
      setNotes(updated);
      if (selectedNote?.id === id) {
        setSelectedNote(updated.length > 0 ? updated[0] : null);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const exportNotesAsMarkdown = () => {
    if (notes.length === 0) return;
    const text = notes
      .map(
        (n) =>
          `# ${n.title}\n*Type: ${n.note_type} | Tags: ${n.tags?.join(", ") || "none"}*\n\n${n.content}\n\n---\n`
      )
      .join("\n");

    const blob = new Blob([text], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `FinanceHub_Notes_${new Date().toISOString().slice(0, 10)}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const filteredNotes = notes.filter((n) => {
    if (showPinnedOnly && !n.is_pinned) return false;
    if (selectedType !== "all" && n.note_type !== selectedType) return false;
    if (selectedTag && (!n.tags || !n.tags.includes(selectedTag))) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const matchTitle = n.title.toLowerCase().includes(q);
      const matchContent = n.content.toLowerCase().includes(q);
      const matchLesson = n.lesson_title?.toLowerCase().includes(q);
      return matchTitle || matchContent || matchLesson;
    }
    return true;
  });

  return (
    <AppLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-fade-in">
        {/* Header & Quick Action */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-semibold mb-2">
              <PencilSquareIcon className="w-4 h-4" />
              Your Personal Finance Rough Book
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
              Digital Notes & Scratchpad
            </h1>
            <p className="text-sm text-slate-400 mt-1">
              Organize study takeaways, formulas, fast math calculations, and lesson bookmarks.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={exportNotesAsMarkdown}
              className="px-3.5 py-2 rounded-xl border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-2 transition"
            >
              <ArrowDownTrayIcon className="w-4 h-4" />
              Export .MD
            </button>
            <button
              onClick={() => setIsRoughBookOpen(true)}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-semibold shadow-lg shadow-amber-500/10 flex items-center gap-2 transition"
            >
              <PlusIcon className="w-4 h-4" />
              New Quick Note / Math
            </button>
          </div>
        </div>

        {/* Filters and Search Bar */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex flex-col md:flex-row items-center gap-3">
            {/* Search Input */}
            <div className="relative flex-1 w-full">
              <MagnifyingGlassIcon className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search notes, lessons, formulas, keywords..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500/50"
              />
            </div>

            {/* Filter buttons */}
            <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
              <button
                onClick={() => setShowPinnedOnly(!showPinnedOnly)}
                className={`px-3 py-2 rounded-xl text-xs font-medium transition flex items-center gap-1.5 whitespace-nowrap ${
                  showPinnedOnly
                    ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                    : "bg-slate-950 border border-slate-800 text-slate-400 hover:text-white"
                }`}
              >
                <PinIcon className="w-3.5 h-3.5" />
                Pinned
              </button>

              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="bg-slate-950 border border-slate-800 text-slate-300 text-xs rounded-xl px-3 py-2 focus:outline-none"
              >
                <option value="all">All Types</option>
                <option value="lesson">Lesson Notes</option>
                <option value="formula">Formulas & Math</option>
                <option value="concept">Concepts</option>
                <option value="general">General Scratchpad</option>
              </select>
            </div>
          </div>

          {/* Tags list */}
          {allTags.length > 0 && (
            <div className="flex flex-wrap items-center gap-1.5 pt-1 border-t border-slate-800/60">
              <span className="text-[11px] text-slate-500 flex items-center gap-1 mr-1">
                <TagIcon className="w-3 h-3" /> Filter by tag:
              </span>
              <button
                onClick={() => setSelectedTag(null)}
                className={`px-2 py-0.5 rounded-md text-[11px] transition ${
                  selectedTag === null ? "bg-amber-500/20 text-amber-300 font-semibold" : "bg-slate-800/80 text-slate-400 hover:text-white"
                }`}
              >
                All
              </button>
              {allTags.map((t) => (
                <button
                  key={t}
                  onClick={() => setSelectedTag(selectedTag === t ? null : t)}
                  className={`px-2 py-0.5 rounded-md text-[11px] transition ${
                    selectedTag === t ? "bg-amber-500 text-slate-950 font-semibold" : "bg-slate-800/80 text-slate-400 hover:text-white"
                  }`}
                >
                  #{t}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Main 2-Column Note Studio Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Notes Grid (5 cols) */}
          <div className="lg:col-span-5 space-y-3">
            <div className="flex items-center justify-between px-1">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                Notes ({filteredNotes.length})
              </span>
            </div>

            {isLoading ? (
              <div className="p-12 text-center text-xs text-slate-500">Loading your notes...</div>
            ) : filteredNotes.length === 0 ? (
              <div className="p-8 rounded-2xl bg-slate-900/40 border border-dashed border-slate-800 text-center space-y-3">
                <BookmarkIcon className="w-8 h-8 text-slate-600 mx-auto" />
                <p className="text-xs text-slate-400">No notes found matching your filters.</p>
                <button
                  onClick={() => setIsRoughBookOpen(true)}
                  className="text-xs text-amber-400 hover:underline font-medium"
                >
                  + Create your first note
                </button>
              </div>
            ) : (
              <div className="space-y-3 max-h-[680px] overflow-y-auto pr-1">
                {filteredNotes.map((n) => {
                  const style = COLOR_CONFIG[n.color] || COLOR_CONFIG.yellow;
                  const isSelected = selectedNote?.id === n.id;
                  return (
                    <div
                      key={n.id}
                      onClick={() => setSelectedNote(n)}
                      className={`p-4 rounded-2xl border transition cursor-pointer relative group text-left ${
                        isSelected
                          ? `${style.bg} ${style.border} ring-2 ring-amber-500/40 shadow-lg`
                          : "bg-slate-900 border-slate-800 hover:border-slate-700"
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2">
                          <span className={`w-2.5 h-2.5 rounded-full ${style.dot}`} />
                          <h3 className="text-sm font-semibold text-white truncate max-w-[220px]">
                            {n.title}
                          </h3>
                        </div>

                        <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleTogglePin(n);
                            }}
                            className={`p-1 rounded hover:bg-slate-800 transition ${
                              n.is_pinned ? "text-amber-400" : "text-slate-500"
                            }`}
                            title="Pin Note"
                          >
                            <PinIcon className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {n.lesson_title && (
                        <div className="text-[11px] text-slate-400 flex items-center gap-1 mb-2 bg-slate-950/60 px-2 py-0.5 rounded-lg w-fit">
                          <span>{n.track_icon || "📖"}</span>
                          <span className="truncate max-w-[240px]">{n.lesson_title}</span>
                        </div>
                      )}

                      <p className="text-xs text-slate-300 font-mono line-clamp-3 leading-relaxed whitespace-pre-wrap">
                        {n.content}
                      </p>

                      <div className="flex items-center justify-between pt-3 border-t border-slate-800/40 mt-3 text-[10px] text-slate-500">
                        <div className="flex items-center gap-1">
                          {n.tags?.slice(0, 3).map((t) => (
                            <span key={t} className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                              #{t}
                            </span>
                          ))}
                        </div>
                        <span>{new Date(n.updated_at).toLocaleDateString()}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Active Note Preview / Viewer (7 cols) */}
          <div className="lg:col-span-7">
            {selectedNote ? (
              <div className={`p-6 rounded-2xl border transition space-y-5 ${
                COLOR_CONFIG[selectedNote.color]?.bg || "bg-slate-900"
              } ${
                COLOR_CONFIG[selectedNote.color]?.border || "border-slate-800"
              }`}>
                {/* Note Header */}
                <div className="flex items-start justify-between gap-4 border-b border-slate-800/60 pb-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className={`w-3 h-3 rounded-full ${COLOR_CONFIG[selectedNote.color]?.dot || "bg-amber-400"}`} />
                      <h2 className="text-xl font-bold text-white">{selectedNote.title}</h2>
                    </div>
                    {selectedNote.lesson_title && (
                      <p className="text-xs text-slate-400">
                        Lesson Context: <span className="text-amber-300 font-medium">{selectedNote.lesson_title}</span>
                      </p>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleTogglePin(selectedNote)}
                      className={`p-2 rounded-xl border text-xs font-medium transition flex items-center gap-1 ${
                        selectedNote.is_pinned
                          ? "bg-amber-500/20 text-amber-300 border-amber-500/30"
                          : "border-slate-800 text-slate-400 hover:text-white"
                      }`}
                    >
                      <PinIcon className="w-4 h-4" />
                      {selectedNote.is_pinned ? "Pinned" : "Pin"}
                    </button>
                    <button
                      onClick={() => handleDeleteNote(selectedNote.id)}
                      className="p-2 rounded-xl border border-slate-800 text-slate-500 hover:text-rose-400 hover:border-rose-500/30 transition"
                      title="Delete Note"
                    >
                      <TrashIcon className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Content Box */}
                <div className="p-5 rounded-xl bg-slate-950/70 border border-slate-800/80 text-sm text-slate-100 font-sans leading-relaxed whitespace-pre-wrap">
                  {selectedNote.content}
                </div>

                {/* Tags & Metadata */}
                <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400 pt-2">
                  <div className="flex items-center gap-1.5">
                    <TagIcon className="w-3.5 h-3.5" />
                    {selectedNote.tags && selectedNote.tags.length > 0 ? (
                      selectedNote.tags.map((t) => (
                        <span key={t} className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 text-[11px]">
                          #{t}
                        </span>
                      ))
                    ) : (
                      <span className="text-slate-600">No tags</span>
                    )}
                  </div>

                  <span>Last edited: {new Date(selectedNote.updated_at).toLocaleString()}</span>
                </div>
              </div>
            ) : (
              <div className="p-16 rounded-2xl bg-slate-900 border border-slate-800 text-center space-y-3">
                <PencilSquareIcon className="w-10 h-10 text-slate-600 mx-auto" />
                <h3 className="text-sm font-semibold text-white">Select a note to view</h3>
                <p className="text-xs text-slate-400">Choose any note from the left list or create a new scratch note.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Floating Modal for Quick Notes & Math */}
      <RoughBookModal
        isOpen={isRoughBookOpen}
        onClose={() => {
          setIsRoughBookOpen(false);
          fetchNotes();
        }}
      />
    </AppLayout>
  );
}
