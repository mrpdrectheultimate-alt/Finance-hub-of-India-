// ============================================================
// FinanceHub — Trading Theater Expansion: Scenarios 13–20
// trading_theater_expansion.tsx
//
// Append ALL_NEW_SCENARIOS to SCENARIOS array in:
// trading_theater_page.tsx + trading_theater_scenarios.tsx
//
// Scenarios:
//  13. Candlestick Pattern Trade
//  14. VWAP Intraday Strategy
//  15. Short Selling — Profit in Falling Market
//  16. Gap Up / Gap Down Opening Strategy
//  17. F&O Expiry Day — Theta Decay
//  18. Stop-Loss Hunt — Operator Trap
//  19. Bitcoin Breakout Trade
//  20. Trade Journal Review
// ============================================================

export interface Candle {
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  time: string;
}

export interface Checkpoint {
  question: string;
  options: string[];
  correct: number;
  explanation: string;
}

export interface Step {
  id: number;
  title: string;
  narration: string;
  action: string;
  calculation?: string;
  rule?: string;
  highlight?: number[];
  chartAction?: "draw_support" | "draw_resistance" | "mark_entry" | "mark_exit" | "trail_stop" | "draw_fib" | "draw_ma" | "highlight_candle" | "show_compound";
  chartData?: Record<string, number>;
  checkpoint?: Checkpoint;
  pause?: boolean;
}

export interface Scenario {
  id: string;
  title: string;
  subtitle: string;
  category: string;
  difficulty: "Beginner" | "Intermediate" | "Advanced";
  duration: string;
  icon: string;
  isPro: boolean;
  disclaimer: string;
  steps: Step[];
  candles: Candle[];
  instrument: string;
  timeframe: string;
  dataSource: string;
}

// ── CANDLE DATA ───────────────────────────────────────────────

export const BEARISH_CANDLES: Candle[] = [
  { open:3200, high:3240, low:3180, close:3220, volume:900000,  time:"Day 1" },
  { open:3220, high:3250, low:3200, close:3240, volume:800000,  time:"Day 2" },
  { open:3240, high:3280, low:3220, close:3260, volume:1000000, time:"Day 3" },
  { open:3260, high:3300, low:3240, close:3280, volume:1200000, time:"Day 4" },
  { open:3280, high:3320, low:3260, close:3300, volume:1400000, time:"Day 5" },
  { open:3300, high:3330, low:3270, close:3280, volume:1600000, time:"Day 6" },
  { open:3280, high:3290, low:3230, close:3240, volume:1800000, time:"Day 7" },
  { open:3240, high:3250, low:3180, close:3190, volume:2000000, time:"Day 8" },
  { open:3190, high:3210, low:3140, close:3150, volume:2200000, time:"Day 9" },
  { open:3150, high:3160, low:3080, close:3090, volume:2400000, time:"Day 10" },
  { open:3090, high:3100, low:3020, close:3040, volume:2200000, time:"Day 11" },
  { open:3040, high:3060, low:2980, close:3000, volume:2000000, time:"Day 12" },
  { open:3000, high:3030, low:2950, close:2970, volume:1800000, time:"Day 13" },
  { open:2970, high:3010, low:2930, close:2960, volume:1600000, time:"Day 14" },
  { open:2960, high:2990, low:2920, close:2940, volume:1400000, time:"Day 15" },
];

export const CANDLESTICK_CANDLES: Candle[] = [
  { open:580, high:595, low:575, close:590, volume:500000, time:"09:15" },
  { open:590, high:600, low:582, close:585, volume:600000, time:"09:30" },
  { open:585, high:592, low:570, close:572, volume:800000, time:"09:45" },
  { open:572, high:578, low:558, close:562, volume:900000, time:"10:00" },
  { open:562, high:570, low:548, close:552, volume:1000000, time:"10:15" },
  { open:552, high:558, low:540, close:555, volume:1200000, time:"10:30" },
  { open:555, high:580, low:552, close:578, volume:1800000, time:"10:45" },
  { open:578, high:598, low:576, close:595, volume:2000000, time:"11:00" },
  { open:595, high:618, low:593, close:615, volume:1800000, time:"11:15" },
  { open:615, high:635, low:612, close:630, volume:1600000, time:"11:30" },
  { open:630, high:648, low:628, close:645, volume:1400000, time:"11:45" },
  { open:645, high:660, low:642, close:655, volume:1200000, time:"12:00" },
  { open:655, high:668, low:652, close:663, volume:1000000, time:"12:15" },
  { open:663, high:672, low:660, close:669, volume:900000, time:"12:30" },
  { open:669, high:678, low:666, close:675, volume:800000, time:"12:45" },
];

export const GAP_CANDLES: Candle[] = [
  { open:21900, high:21940, low:21870, close:21920, volume:900000,  time:"Prev D" },
  { open:22080, high:22140, low:22060, close:22120, volume:1800000, time:"09:15" },
  { open:22120, high:22160, low:22090, close:22100, volume:1400000, time:"09:20" },
  { open:22100, high:22130, low:22070, close:22085, volume:1100000, time:"09:25" },
  { open:22085, high:22100, low:22060, close:22075, volume:900000,  time:"09:30" },
  { open:22075, high:22090, low:22050, close:22080, volume:800000,  time:"09:35" },
  { open:22080, high:22100, low:22070, close:22095, volume:850000,  time:"09:40" },
  { open:22095, high:22120, low:22088, close:22115, volume:950000,  time:"09:45" },
  { open:22115, high:22150, low:22110, close:22145, volume:1200000, time:"09:50" },
  { open:22145, high:22190, low:22140, close:22180, volume:1500000, time:"09:55" },
  { open:22180, high:22230, low:22175, close:22220, volume:1800000, time:"10:00" },
  { open:22220, high:22270, low:22215, close:22260, volume:1600000, time:"10:05" },
  { open:22260, high:22300, low:22255, close:22290, volume:1400000, time:"10:10" },
  { open:22290, high:22330, low:22285, close:22320, volume:1200000, time:"10:15" },
  { open:22320, high:22360, low:22315, close:22350, volume:1000000, time:"10:20" },
];

export const BTC_CANDLES: Candle[] = [
  { open:62000, high:62800, low:61500, close:62600, volume:800,  time:"Day 1" },
  { open:62600, high:63400, low:62200, close:63100, volume:900,  time:"Day 2" },
  { open:63100, high:63800, low:62800, close:63500, volume:1000, time:"Day 3" },
  { open:63500, high:64200, low:63200, close:64000, volume:1100, time:"Day 4" },
  { open:64000, high:64800, low:63700, close:64500, volume:1200, time:"Day 5" },
  { open:64500, high:65000, low:64200, close:64600, volume:1000, time:"Day 6" },
  { open:64600, high:64900, low:64100, close:64200, volume:900,  time:"Day 7" },
  { open:64200, high:64500, low:63800, close:64000, volume:850,  time:"Day 8" },
  { open:64000, high:64200, low:63600, close:63800, volume:800,  time:"Day 9" },
  { open:63800, high:64600, low:63700, close:64500, volume:1300, time:"Day 10" },
  { open:64500, high:65800, low:64400, close:65600, volume:1600, time:"Day 11" },
  { open:65600, high:67200, low:65500, close:67000, volume:2000, time:"Day 12" },
  { open:67000, high:68500, low:66800, close:68200, volume:2400, time:"Day 13" },
  { open:68200, high:70000, low:68000, close:69800, volume:2800, time:"Day 14" },
  { open:69800, high:71500, low:69500, close:71200, volume:2600, time:"Day 15" },
];

export const EXPIRY_CANDLES: Candle[] = [
  { open:22200, high:22250, low:22180, close:22230, volume:2000000, time:"09:15" },
  { open:22230, high:22280, low:22210, close:22260, volume:2500000, time:"09:30" },
  { open:22260, high:22310, low:22240, close:22290, volume:3000000, time:"09:45" },
  { open:22290, high:22340, low:22270, close:22320, volume:3500000, time:"10:00" },
  { open:22320, high:22360, low:22290, close:22310, volume:4000000, time:"10:15" },
  { open:22310, high:22340, low:22270, close:22280, volume:4500000, time:"10:30" },
  { open:22280, high:22300, low:22240, close:22250, volume:5000000, time:"10:45" },
  { open:22250, high:22270, low:22210, close:22220, volume:5500000, time:"11:00" },
  { open:22220, high:22240, low:22180, close:22190, volume:6000000, time:"11:15" },
  { open:22190, high:22210, low:22150, close:22160, volume:6500000, time:"11:30" },
  { open:22160, high:22180, low:22120, close:22130, volume:7000000, time:"11:45" },
  { open:22130, high:22150, low:22090, close:22100, volume:7500000, time:"12:00" },
  { open:22100, high:22120, low:22060, close:22070, volume:8000000, time:"12:15" },
  { open:22070, high:22090, low:22030, close:22040, volume:8500000, time:"12:30" },
  { open:22040, high:22060, low:22000, close:22010, volume:9000000, time:"12:45" },
];

// ── ALL 8 NEW SCENARIOS ───────────────────────────────────────
export const ALL_NEW_SCENARIOS: Scenario[] = [

  // ── SCENARIO 13: CANDLESTICK PATTERN TRADE ──────────────────
  {
    id: "candlestick-pattern-trade",
    title: "Candlestick Pattern Trade",
    subtitle: "Hammer + Bullish Engulfing — reading candles and entering live",
    category: "Price Action",
    difficulty: "Beginner",
    duration: "5 min",
    icon: "🕯️",
    isPro: false,
    instrument: "HDFC Bank",
    timeframe: "15-minute chart",
    dataSource: "Historical simulation — October 2024",
    disclaimer: "Educational simulation using historical data. Not investment advice.",
    candles: CANDLESTICK_CANDLES,
    steps: [
      {
        id: 1,
        title: "What Candlesticks Actually Tell You",
        narration: "Every single candlestick is a war between buyers and sellers compressed into one time period. The body shows who won — green means buyers won, red means sellers won. The wicks show how far each side fought before losing. A long lower wick with a small green body — called a Hammer — tells us sellers tried hard to push price down but buyers completely overwhelmed them by the close. This is powerful information.",
        action: "Anatomy of a candlestick — body, wick, open, close",
        rule: "Rule 1: Read the STORY of each candle — who tried what, and who actually won",
        calculation: "Hammer anatomy:\nOpen: ₹562 | Low: ₹540 | Close: ₹555\nBody size: ₹ 7 (small — sellers and buyers balanced at close)\nLower wick: ₹22 (sellers pushed hard)\nUpper wick: ₹3 (buyers pushed slightly)\nInterpretation: Sellers failed. Buyers now in control.",
      },
      {
        id: 2,
        title: "The Hammer Candle — Recognizing It",
        narration: "Candle 6 on our chart is a classic Hammer. Price has been falling for 5 candles. Then suddenly: price opens at 552, sellers push it all the way down to 540 — a new low. But then buyers completely reverse it, closing at 555 — almost exactly where it opened. The lower wick is 3 times the body size. This is the definition of a Hammer. It does NOT mean buy immediately. It means: be alert, watch the NEXT candle for confirmation.",
        action: "Highlighting the Hammer candle at candle 6",
        highlight: [5],
        chartAction: "highlight_candle",
        rule: "Rule 2: Hammer signals possible reversal. Wait for NEXT candle to close ABOVE the Hammer's high for confirmation.",
        checkpoint: {
          question: "You see a perfect Hammer candle. The NEXT candle opens up but comes back down and closes BELOW the Hammer's low. What does this mean?",
          options: [
            "The Hammer still works — wait for one more candle",
            "The Hammer is invalidated — sellers have overpowered buyers again",
            "Buy more — this is a better entry",
            "The pattern needs 3 candles to confirm",
          ],
          correct: 1,
          explanation: "If the next candle closes below the Hammer's low, the pattern is completely invalidated. The seller pushed back and won. This is why we ALWAYS wait for confirmation and have a stop below the Hammer's low — if that level breaks, we are wrong.",
        },
        pause: true,
      },
      {
        id: 3,
        title: "The Bullish Engulfing — Double Confirmation",
        narration: "Candle 7 is even more powerful — a Bullish Engulfing. It opens BELOW the previous red candle's close and closes ABOVE the previous red candle's open. The green body completely engulfs the previous red body. This is the highest-probability single-candle reversal pattern. We now have two confirmations: the Hammer at candle 6 and the Engulfing at candle 7. Entry is now valid.",
        action: "Highlighting Bullish Engulfing candle 7 with the Hammer context",
        highlight: [5, 6],
        chartAction: "highlight_candle",
        rule: "Rule 3: Bullish Engulfing after a downtrend = highest-confidence entry signal",
        calculation: "Bullish Engulfing at candle 7:\nPrevious red: Open 552 → Close 555\nEngulfing green: Open 552 → Close 578\nBody completely covers previous red body ✅\nVolume: 1,800,000 vs 1,200,000 average ✅ (1.5x)\nBoth confirmations met — VALID ENTRY",
      },
      {
        id: 4,
        title: "Entry, Stop and Target",
        narration: "We enter at 580 — just above the Engulfing candle's high. Stop goes below the Hammer's low at 540 — this is the level that, if broken, completely invalidates the bullish pattern. Risk is 40 rupees. Target is previous resistance at 660 — a 80-rupee reward. Risk-reward: 1 to 2. Position size on 1 lakh capital at 1% risk: 1,000 rupees divided by 40 equals 25 shares.",
        action: "Placing buy order above Engulfing candle high",
        rule: "Rule 4: Entry above Engulfing high. Stop below Hammer low. Never compromise these levels.",
        calculation: "Entry: ₹580 | Stop: ₹540 | Target: ₹660\nRisk: 40 pts | Reward: 80 pts | RR: 1:2\nCapital: ₹1,00,000 | 1% Risk: ₹1,000\nPosition: 1,000 ÷ 40 = 25 shares",
        chartAction: "mark_entry",
        chartData: { entry: 580, stop: 540 },
      },
      {
        id: 5,
        title: "Target Hit — Candlestick Trade Complete",
        narration: "After the Hammer and Engulfing confirmed the reversal, HDFC Bank rallied from 580 to 675 — well beyond our target of 660. We exit at 660. Profit: 25 shares times 80 rupees equals 2,000 rupees on 1,000 rupees risk. A perfect 1-to-2 risk-reward trade. The pattern worked because we had multiple confirmations, traded at a key level after a downtrend, and had volume supporting the move.",
        action: "Exiting at resistance target — trade complete",
        calculation: "Entry: ₹580 | Exit: ₹660 | Stop: ₹540\nProfit: 25 × 80 = ₹2,000 on ₹1,000 risk\nRR achieved: 1:2 ✅\n\nKey lessons:\n• Hammer alone = alert, not entry\n• Engulfing confirms = valid entry\n• Volume must confirm\n• Stop below Hammer low — always",
        chartAction: "mark_exit",
        chartData: { exit: 660 },
      },
    ],
  },

  // ── SCENARIO 14: VWAP INTRADAY ──────────────────────────────
  {
    id: "vwap-intraday-strategy",
    title: "VWAP Intraday Strategy",
    subtitle: "Volume Weighted Average Price — the institutional trader's reference line",
    category: "Intraday",
    difficulty: "Intermediate",
    duration: "5 min",
    icon: "📐",
    isPro: false,
    instrument: "NIFTY 50",
    timeframe: "5-minute chart",
    dataSource: "Historical simulation — October 2024",
    disclaimer: "Educational simulation using historical data. Not investment advice.",
    candles: GAP_CANDLES,
    steps: [
      {
        id: 1,
        title: "What VWAP Is and Why It Matters",
        narration: "VWAP — Volume Weighted Average Price — is the average price at which all trades have occurred during the day, weighted by volume. It is NOT just a simple average. A trade of 10,000 shares at 22,100 counts 10,000 times more than a trade of 1 share at 22,150. VWAP is the single most important reference level for institutional traders. Why? Because large institutions measure their execution quality against VWAP. If they bought below VWAP, they did well. If above, they overpaid.",
        action: "Drawing VWAP line on intraday chart",
        rule: "Rule 1: Price above VWAP = bullish bias for the day. Price below VWAP = bearish bias.",
        chartAction: "draw_ma",
      },
      {
        id: 2,
        title: "The VWAP Pullback Entry",
        narration: "The highest-probability VWAP trade is this: price is above VWAP, showing bullish bias. Price then pulls back TO the VWAP line. At VWAP, institutional buyers who want to buy below their benchmark price step in. Price bounces. We ride this institutional buying. Today NIFTY opened with a gap up, established bullish trend, pulled back to VWAP at 22,080, and formed a small base. This is our entry zone.",
        action: "Price pulling back to VWAP — marking entry zone",
        rule: "Rule 2: Buy at VWAP only when the overall trend is UP (price was above VWAP before pullback)",
        checkpoint: {
          question: "NIFTY has been BELOW VWAP all morning. Price touches VWAP from below. Is this a buy signal?",
          options: [
            "Yes — price touching VWAP is always a buy",
            "No — price below VWAP all day = bearish. VWAP touch from below is resistance, not support",
            "Yes — VWAP is always support",
            "Only if volume is high",
          ],
          correct: 1,
          explanation: "Correct. VWAP context is everything. If price has been BELOW VWAP, the trend is bearish and VWAP acts as RESISTANCE — not support. Only buy VWAP when price has been ABOVE VWAP (bullish day) and pulls back to it. On bearish days, sell VWAP bounces.",
        },
        pause: true,
      },
      {
        id: 3,
        title: "Entry and Exit Rules",
        narration: "NIFTY pulls back to VWAP at 22,080 from above. A small green candle forms at VWAP — the bounce confirmation. We enter at 22,095. Stop goes below VWAP at 22,055 — if price breaks and closes below VWAP, the bullish thesis is done. Target is the morning high at 22,180, with a secondary target of 22,250. Risk 40 points, reward 85 to 155 points.",
        action: "Entering on VWAP bounce with tight stop below VWAP",
        rule: "Rule 3: Stop goes BELOW VWAP — if price closes a candle below VWAP, exit immediately",
        calculation: "Entry: 22,095 | Stop: 22,055 | Target 1: 22,180 | Target 2: 22,250\nRisk: 40 pts | Reward 1: 85 pts (1:2.1) | Reward 2: 155 pts (1:3.9)\nCapital: ₹5,00,000 | 1% = ₹5,000\nPosition: 5,000 ÷ 40 = 125 units",
        chartAction: "mark_entry",
        chartData: { entry: 22095, stop: 22055 },
      },
      {
        id: 4,
        title: "VWAP Trade Result",
        narration: "After the VWAP bounce, NIFTY rallied to 22,350 — well beyond both targets. First target at 22,180: 50% exit — profit 85 points times 62 units equals 5,270 rupees. Second exit at 22,250 as day closes out: 63 units times 155 points equals 9,765 rupees. Total: 15,035 rupees on 5,000 rupees risk. VWAP strategies work because they align retail traders with institutional flow — the most powerful force in markets.",
        action: "Exiting in two parts as price reaches targets",
        calculation: "Exit 1 (50%) at 22,180: 62 units × 85 pts = ₹5,270\nExit 2 (50%) at 22,250: 63 units × 155 pts = ₹9,765\nTotal: ₹15,035 on ₹5,000 risk | RR: 1:3\n\nVWAP works because:\n• Institutions use it as benchmark\n• Self-fulfilling at key intraday levels\n• Combines price AND volume context",
        chartAction: "mark_exit",
        chartData: { exit: 22250 },
      },
    ],
  },

  // ── SCENARIO 15: SHORT SELLING ──────────────────────────────
  {
    id: "short-selling-basics",
    title: "Short Selling — Profiting from Falling Markets",
    subtitle: "How to sell what you don't own and buy it back cheaper",
    category: "Advanced Strategies",
    difficulty: "Intermediate",
    duration: "5 min",
    icon: "📉",
    isPro: false,
    instrument: "Nifty IT Index (Futures)",
    timeframe: "Daily chart",
    dataSource: "Historical simulation — 2024",
    disclaimer: "Short selling carries unlimited risk potential. Educational only. Not investment advice.",
    candles: BEARISH_CANDLES,
    steps: [
      {
        id: 1,
        title: "What Short Selling Actually Is",
        narration: "Most beginners only know how to profit when markets go UP. Short selling allows you to profit when markets go DOWN. Here is how it works. You borrow shares from your broker. You sell them immediately at today's high price. Later, when the price has fallen, you buy the shares back at the lower price. You return them to the broker and keep the difference as profit. In India, intraday short selling on stocks and short futures are the two main methods.",
        action: "Animated diagram — borrow, sell high, buy low, return",
        rule: "Rule 1: Short selling = sell first, buy later. Profit when price FALLS.",
        calculation: "Short selling example:\nDay 1: Borrow 100 shares. Sell at ₹3,300 each = ₹3,30,000 received\nDay 5: Buy back at ₹3,040 each = ₹3,04,000 paid\nReturn shares to broker\nProfit: ₹3,30,000 − ₹3,04,000 = ₹26,000\nNote: If price RISES instead, you LOSE money — unlimited risk",
      },
      {
        id: 2,
        title: "Identifying a Short Setup",
        narration: "The IT index has broken below a key support zone at 3,270 with expanding volume. This is our signal — a breakdown. Breakdown characteristics: price closes below support, volume is higher than average, and the candle bodies are large red candles showing strong selling. We look for short entries on pullbacks to the broken support level — which now becomes resistance.",
        action: "Marking support breakdown and pullback entry zone",
        rule: "Rule 2: Short breakdowns on retest of broken support — not on the initial breakdown candle",
        highlight: [5, 6, 7],
        chartAction: "highlight_candle",
        checkpoint: {
          question: "Price breaks below support at ₹3,270 aggressively. What is the BEST short entry strategy?",
          options: [
            "Short immediately on the breakdown candle at market price",
            "Wait for price to pull back up and RETEST ₹3,270 from below, then short",
            "Short when price reaches the next support at ₹3,000",
            "Short selling is too risky — avoid it completely",
          ],
          correct: 1,
          explanation: "Wait for the retest. When support breaks, price often pulls back UP to retest that level — which now becomes resistance. This gives a better entry price, clearer stop-loss placement, and better risk-reward. Chasing the initial breakdown gets you in at the worst price.",
        },
        pause: true,
      },
      {
        id: 3,
        title: "Short Entry with Proper Stop Loss",
        narration: "Price pulled back to 3,270 after the breakdown — exactly as expected. Sellers defended this level perfectly, forming a red candle at resistance. We enter SHORT at 3,250 — below the pullback candle's low. Stop goes ABOVE the resistance at 3,310. If price breaks back above 3,310, our bearish thesis is wrong. Target is the next support at 2,960 — a 290-point move.",
        action: "Short entry at retest of broken support, stop above resistance",
        rule: "Rule 3: Short stop goes ABOVE resistance. For long trades, stop goes BELOW support.",
        calculation: "Short Entry: ₹3,250 | Stop: ₹3,310 | Target: ₹2,960\nRisk: 60 pts | Reward: 290 pts | RR: 1:4.8\nCapital: ₹5,00,000 | 1% Risk: ₹5,000\nPosition: 5,000 ÷ 60 = 83 units\nNote: In India, use futures for short positions held overnight",
        chartAction: "mark_entry",
        chartData: { entry: 3250, stop: 3310 },
      },
      {
        id: 4,
        title: "Managing and Closing the Short",
        narration: "The IT index fell from 3,250 to 2,960 over 8 trading days — exactly as our breakdown thesis predicted. We cover — buy back — our short at 2,970. Profit: 83 units times 280 points equals 23,240 rupees on 5,000 rupees risk. Important reminder: Short selling has theoretically unlimited risk if price rises instead of falls. Always use stops. Always use futures rather than intraday short for overnight positions in India.",
        action: "Covering short position at target — P&L calculation",
        calculation: "Short entry: ₹3,250 | Cover at: ₹2,970 | Stop: ₹3,310\nProfit: 83 units × 280 pts = ₹23,240\nRisk: ₹5,000 | RR: 1:4.6\n\nRisk warning for short sellers:\nIf price rises: loss grows without limit\nAlways use stop-loss orders\nNever short without predefined exit level",
        chartAction: "mark_exit",
        chartData: { exit: 2970 },
      },
    ],
  },

  // ── SCENARIO 16: GAP STRATEGY ───────────────────────────────
  {
    id: "gap-up-gap-down-strategy",
    title: "Gap Up / Gap Down Opening Strategy",
    subtitle: "How to read and trade the market opening gap every morning",
    category: "Intraday",
    difficulty: "Beginner",
    duration: "4 min",
    icon: "🌅",
    isPro: false,
    instrument: "NIFTY 50",
    timeframe: "5-minute chart",
    dataSource: "Historical simulation — October 2024",
    disclaimer: "Educational simulation using historical data. Not investment advice.",
    candles: GAP_CANDLES,
    steps: [
      {
        id: 1,
        title: "Why Gaps Happen",
        narration: "A gap occurs when today's opening price is significantly different from yesterday's closing price. Gap-up: today opens higher than yesterday's close. Gap-down: today opens lower. Gaps happen because news, earnings, global markets, or RBI decisions create overnight price discovery. NIFTY closed yesterday at 21,920. Today it opened at 22,080 — a 160-point gap up — due to positive US market overnight.",
        action: "Showing gap-up opening — yesterday close vs today open",
        rule: "Rule 1: Gaps above 0.5% are tradeable. Gaps below 0.3% often fill quickly and are noise.",
        calculation: "Yesterday close: 21,920\nToday open: 22,080\nGap size: 160 points = 0.73% ✅ (Tradeable gap)\nGap type: Gap-Up (bullish overnight sentiment)\nSGX Nifty pre-market: Showed 22,060 — gap was expected",
      },
      {
        id: 2,
        title: "Gap Fill vs Gap and Go",
        narration: "Every gap trader must know two scenarios. Gap Fill: price reverses after opening and goes back to fill the gap — closing the space between yesterday's close and today's open. Gap and Go: price continues in the direction of the gap — the gap was caused by a fundamental shift and price keeps moving. Statistically, about 70% of gaps fill within 3 trading days. Today we determine which scenario by watching the first 15 minutes.",
        action: "Demonstrating gap fill vs gap and go with two scenario arrows",
        rule: "Rule 2: Watch the first 15-minute candle direction to determine gap fill or gap and go",
        checkpoint: {
          question: "NIFTY gaps up 200 points. In the first 15 minutes, it falls 80 points from the gap-up open and forms a red candle. What scenario is likely playing out?",
          options: [
            "Gap and Go — still bullish, buy the dip",
            "Gap Fill — price wants to return to yesterday's close",
            "Normal trading — 200 points means nothing",
            "Cannot tell from only 15 minutes of data",
          ],
          correct: 1,
          explanation: "A large red candle in the first 15 minutes after a gap-up is a strong gap-fill signal. Sellers stepped in immediately at the higher prices — indicating the gap-up was overdone. Gap-fill strategy: wait for a retest of the previous day's high (first resistance), then short toward the gap fill target near yesterday's close.",
        },
        pause: true,
      },
      {
        id: 3,
        title: "The Gap and Go Trade",
        narration: "Today's gap-up held. The first 15-minute candle was green and strong, closing at 22,120 — above the opening gap. After a brief consolidation between 9:30 and 9:45, price resumed upward. This is Gap and Go. Entry: buy when price breaks above the 15-minute opening high at 22,140. Stop: below the opening candle low at 22,060 — if price returns to fill the gap, our thesis is wrong.",
        action: "Entry on Gap and Go breakout above first 15-min high",
        rule: "Rule 3: Gap and Go entry = break of first 15-minute candle high. Stop = first 15-minute candle low.",
        calculation: "First 15-min candle: Open 22,080 | High 22,140 | Low 22,060 | Close 22,120\nEntry (above high): 22,145\nStop (below low): 22,055\nTarget: Yesterday's high + Gap size = 21,940 + 160 = 22,100... \nActually: Next round resistance = 22,350\nRisk: 90 pts | Reward: 205 pts | RR: 1:2.3",
        chartAction: "mark_entry",
        chartData: { entry: 22145, stop: 22055 },
      },
      {
        id: 4,
        title: "Gap Trade Complete",
        narration: "NIFTY continued the Gap and Go move reaching 22,350. Exit at target. Profit: approximately 205 points times position size. The key takeaway: gaps are daily opportunities but require careful reading of the first 15 minutes. Never trade before the first 15-minute candle closes. Never chase a gap open blindly. Always identify: is this gap filling or going?",
        action: "Exit at resistance target — Gap and Go complete",
        calculation: "Entry: 22,145 | Exit: 22,350 | Stop: 22,055\nProfit: 205 pts | Risk: 90 pts | RR: 1:2.3\n\nGap Strategy Summary:\n• Gap > 0.5%: Watch first 15 min\n• First 15 min green + gap holds = Gap and Go\n• First 15 min red + gap struggles = Gap Fill\n• Never trade the first 5 minutes",
        chartAction: "mark_exit",
        chartData: { exit: 22350 },
      },
    ],
  },

  // ── SCENARIO 17: F&O EXPIRY DAY ─────────────────────────────
  {
    id: "fo-expiry-day-strategy",
    title: "F&O Expiry Day — Theta Decay in Action",
    subtitle: "What really happens on Thursday and how to navigate it safely",
    category: "Derivatives",
    difficulty: "Advanced",
    duration: "6 min",
    icon: "⏱️",
    isPro: true,
    instrument: "NIFTY Options — Weekly Expiry",
    timeframe: "5-minute chart",
    dataSource: "Historical simulation — October 2024",
    disclaimer: "F&O trading involves significant risk. 89% of individual F&O traders lose money (SEBI 2023). Educational only.",
    candles: EXPIRY_CANDLES,
    steps: [
      {
        id: 1,
        title: "Why Expiry Day is Different",
        narration: "Every Thursday — weekly NIFTY option expiry — is the most dangerous and most opportunity-rich trading day of the week. Why? Because options expiring today lose ALL their time value by 3:30 PM. Theta decay, which normally erodes 10-20 rupees per day, accelerates exponentially. An option worth 100 rupees on Monday morning may be worth 8 rupees by Thursday afternoon — even if NIFTY barely moved. The money doesn't disappear — it transfers from option BUYERS to option SELLERS.",
        action: "Theta decay visualization — Monday to Thursday",
        rule: "Rule 1: On expiry day, option sellers have maximum advantage. Option buyers face maximum time pressure.",
        calculation: "NIFTY 22,200 CE — weekly option\nMonday: ₹85 premium\nTuesday: ₹62 premium\nWednesday: ₹38 premium\nThursday 9:15 AM: ₹22 premium\nThursday 12:00 PM: ₹8 premium\nThursday 3:20 PM: ₹1-2 premium (if OTM)\n\nAll premium = pure theta decay if NIFTY stays near 22,200",
      },
      {
        id: 2,
        title: "The Pin Risk — How Expiry Works",
        narration: "NIFTY is trading at 22,200. The 22,200 strike is At-the-Money. As expiry approaches, massive open interest at the 22,200 strike creates what traders call Pin Risk — large option sellers have an incentive to keep NIFTY near 22,200. Above 22,200, calls explode in value — sellers lose. Below 22,200, puts explode — sellers lose. Between them, sellers win. This creates characteristic expiry day behavior: price pinned near round numbers until the last hour.",
        action: "Options chain showing max pain at strike 22,200",
        rule: "Rule 2: On expiry day, NIFTY often gravitates toward Max Pain — the strike with maximum combined option seller profit.",
        calculation: "Max Pain Calculation (simplified):\n22,000 strike: ₹1,84,000 crore open interest\n22,100 strike: ₹2,12,000 crore open interest\n22,200 strike: ₹2,86,000 crore open interest ← Max Pain\n22,300 strike: ₹1,94,000 crore open interest\n22,400 strike: ₹1,52,000 crore open interest\n\nNIFTY gravitates toward 22,200 = Max Pain",
        checkpoint: {
          question: "On expiry morning, NIFTY is at 22,200. You buy a 22,200 CE for ₹22. By 12 PM NIFTY is STILL at 22,200. What happened to your option premium?",
          options: [
            "Still ₹22 — NIFTY didn't move so nothing changed",
            "Rose to ₹30 — more buyers came in",
            "Fell to ₹8 — theta decay accelerated",
            "Expired worthless at ₹0",
          ],
          correct: 2,
          explanation: "Theta decay on expiry day is brutal. Even with NIFTY completely flat, your ₹22 option lost ₹14 in 3 hours purely from time passing. By 3 PM it may be ₹2. This is why buying options on expiry day is extremely high-risk — you need a large, fast move to overcome theta.",
        },
        pause: true,
      },
      {
        id: 3,
        title: "The Safe Approach — Selling Options",
        narration: "On expiry day, the edge lies with OPTION SELLERS, not buyers. We sell an Iron Condor: sell NIFTY 22,100 Put and sell NIFTY 22,300 Call — both expiring today. We collect the premium from both sides. Maximum profit if NIFTY stays between 22,100 and 22,300 — which is where Max Pain suggests. To protect ourselves, we buy a 22,050 Put and a 22,350 Call. This caps our maximum loss.",
        action: "Setting up Iron Condor — selling both sides around current price",
        rule: "Rule 3: On expiry day, selling options near current price is higher probability than buying",
        calculation: "Iron Condor Setup at 10 AM (NIFTY at 22,200):\nSell 22,300 CE at ₹12 | Buy 22,350 CE at ₹6\nSell 22,100 PE at ₹14 | Buy 22,050 PE at ₹8\nNet Premium Collected: (12-6) + (14-8) = ₹12 per unit\n1 lot (50 units) = ₹600 collected\nMax Loss if NIFTY breaches 22,350 or 22,050: ₹1,900\nRisk-Reward: Collect ₹600 to risk ₹1,900 = 31% probability breakeven",
      },
      {
        id: 4,
        title: "Expiry Day Final Hour",
        narration: "Between 2:30 and 3:30 PM is the final hour — most volatile and dangerous. By 2:30 PM our Iron Condor is showing maximum profit with NIFTY at 22,160 — between our strikes. However, large institutions start hedging positions which can cause big last-hour moves. We close our Iron Condor at 2:30 PM — before the final hour chaos. Buy back both sold options for a combined ₹3. Profit: 12 minus 3 equals 9 rupees per unit, times 50 equals 450 rupees.",
        action: "Closing Iron Condor 1 hour before expiry",
        rule: "Rule 4: ALWAYS close expiry day positions by 2:30 PM — never hold into the final chaotic 60 minutes",
        calculation: "Iron Condor Exit at 2:30 PM:\nBuy back 22,300 CE for ₹1\nBuy back 22,100 PE for ₹2\nTotal cost to close: ₹3\nNet profit: ₹12 collected − ₹3 paid = ₹9 per unit\nTotal: 50 units × ₹9 = ₹450 profit\nMax risk was ₹1,900 — risked ₹1,900 to make ₹450\nNote: Works ~70% of weeks when NIFTY stays rangebound",
      },
    ],
  },

  // ── SCENARIO 18: STOP-LOSS HUNT ─────────────────────────────
  {
    id: "stop-loss-hunt-operator-trap",
    title: "Stop-Loss Hunt — The Operator Trap",
    subtitle: "How large players hunt your stop-loss and how to protect yourself",
    category: "Market Mechanics",
    difficulty: "Intermediate",
    duration: "4 min",
    icon: "🪤",
    isPro: false,
    instrument: "Mid-cap Stock",
    timeframe: "5-minute chart",
    dataSource: "Historical simulation — educational demonstration",
    disclaimer: "Educational simulation. Trading involves significant risk. Not investment advice.",
    candles: CANDLESTICK_CANDLES,
    steps: [
      {
        id: 1,
        title: "What is a Stop-Loss Hunt?",
        narration: "Large market participants — institutions, operators, market makers — can see clusters of stop-loss orders in the market through Level 2 data and order flow. They know that most retail traders place stop-losses just below obvious support levels or round numbers. So they push price briefly below those levels — triggering thousands of stop-loss orders which creates a cascade of selling — then immediately reverse and buy all those shares at the now-lower price. Retail traders get stopped out. Operators buy the dip.",
        action: "Animated diagram showing operator stop-loss hunt mechanics",
        rule: "Core Rule: Stop-losses at obvious levels are EASILY targeted. Give your stops breathing room.",
      },
      {
        id: 2,
        title: "Recognizing a Stop Hunt in Real Time",
        narration: "Look at candle 7 on the chart. Price breaks below the obvious support at 552 — exactly where most retail traders placed stops. Notice: the candle WICK goes below 552 but the CLOSE comes back above it. Volume spikes during this wick move. Then price immediately reverses and rallies strongly. This is the classic stop-hunt signature: fast spike below support on high volume, immediate reversal, strong rally. Retail: stopped out at the bottom. Operators: loaded up.",
        action: "Highlighting stop-hunt candle — wick below support, closes above",
        highlight: [5, 6],
        chartAction: "highlight_candle",
        checkpoint: {
          question: "You placed a stop at ₹548 below support at ₹552. Price spikes to ₹542, triggers your stop, then immediately reverses to ₹580. How do you trade this NEXT time?",
          options: [
            "Move stop even tighter to ₹550 to reduce loss",
            "Give stop more room — place at ₹535 below the likely hunt zone",
            "Don't use stop-losses — they always get hunted",
            "Place stop at ₹552 exactly at support",
          ],
          correct: 1,
          explanation: "Give your stop breathing room. If the obvious stop level is ₹548, operators know this. Place yours at ₹535 — below the likely hunt zone. Yes, this means a larger loss if genuinely wrong, so reduce position size to compensate. Never remove stops entirely — that leads to catastrophic losses.",
        },
        pause: true,
      },
      {
        id: 3,
        title: "How to Protect Yourself",
        narration: "Three techniques protect against stop hunts. First: use MENTAL stops, not hard stops, when trading stocks — check price manually near your stop level before exiting. Second: give stops 10 to 15% more room than the obvious level. Third: trail stops only after price has moved significantly in your favor — tight stops early are most vulnerable. The goal is to stay in the trade through noise while exiting on genuine trend reversals.",
        action: "Three protection techniques demonstrated on chart",
        rule: "Protection Rule: Stop below obvious level + 10% buffer. Small position size to compensate for wider stop.",
        calculation: "Example:\nObvious support: ₹552\nWhere most place stop: ₹548 (easily hunted)\nSmarter stop: ₹535 (below likely hunt zone)\n\nPosition size adjustment:\nIf risk at ₹548 = ₹4 per share → 25 shares on ₹100 risk\nIf risk at ₹535 = ₹17 per share → 6 shares on ₹100 risk\nSame rupee risk — harder to trigger — better survival",
      },
    ],
  },

  // ── SCENARIO 19: BITCOIN BREAKOUT ───────────────────────────
  {
    id: "crypto-bitcoin-breakout",
    title: "Bitcoin Breakout Trade",
    subtitle: "Technical breakout on Bitcoin — same principles, different asset",
    category: "Crypto",
    difficulty: "Intermediate",
    duration: "4 min",
    icon: "₿",
    isPro: true,
    instrument: "Bitcoin (BTC/USDT)",
    timeframe: "Daily chart",
    dataSource: "Historical simulation — 2024",
    disclaimer: "Crypto is unregulated in India. 30% tax + 1% TDS applies. Educational only. Not investment advice. Crypto is highly volatile.",
    candles: BTC_CANDLES,
    steps: [
      {
        id: 1,
        title: "Bitcoin Technical Analysis — Same Principles",
        narration: "Bitcoin follows the same technical principles as stocks — support, resistance, breakouts, volume confirmation. The main difference: volatility is 5 to 10 times higher than Nifty. A 5% move in Bitcoin is a normal day. A 5% move in Nifty would be extraordinary. This means position sizes must be proportionally smaller. India's crypto tax: 30% on profits plus 1% TDS on every sell transaction. Factor both into every trade.",
        action: "Bitcoin chart analysis — identifying consolidation zone",
        rule: "Rule 1: Crypto uses same technical analysis as stocks — but position sizes must account for 5-10x higher volatility",
        calculation: "India Crypto Tax (2024):\n30% flat tax on ALL crypto gains (no deduction for losses from other assets)\n1% TDS deducted at source on every sell\n\nExample: Buy BTC at ₹55L, sell at ₹60L\nProfit: ₹5L\nTax: ₹1.5L (30%)\nTDS already deducted: ₹60,000 (1% of ₹60L)\nNet after tax: ₹3.5L profit",
      },
      {
        id: 2,
        title: "The Consolidation and Breakout",
        narration: "Bitcoin consolidated between $63,800 and $65,000 for 3 days — candles 7 through 9. This tight range after a rally shows neither buyers nor sellers dominating. It is coiling before a move. On day 10, Bitcoin breaks above $65,000 with volume more than 1.5 times the 20-day average. This is our breakout signal. The consolidation was the spring loading. The breakout is the release.",
        action: "Marking consolidation zone and breakout candle",
        highlight: [6, 7, 8, 9],
        chartAction: "highlight_candle",
        checkpoint: {
          question: "Bitcoin breaks above resistance at $65,000 but volume is LOWER than average. What does this suggest?",
          options: [
            "Strong breakout — price action confirms volume isn't needed",
            "Weak breakout — low volume suggests lack of conviction, high false breakout risk",
            "Volume never matters in crypto",
            "Buy more — low volume breakouts are the best",
          ],
          correct: 1,
          explanation: "Low volume breakouts in any asset — stocks, crypto, or forex — are high false breakout risk. Without volume confirming the move, there aren't enough buyers to sustain the higher price. Price often falls back into the range. Always require volume confirmation on breakouts.",
        },
        pause: true,
      },
      {
        id: 3,
        title: "Entry and Risk Management for Crypto",
        narration: "Bitcoin breaks $65,000 on day 10 with strong volume. We enter at $65,600 — above the breakout candle's high. Stop goes below the consolidation zone low at $63,600 — a $2,000 stop. Crypto position sizing: with capital of $10,000 and 1% risk ($100), maximum quantity is $100 divided by $2,000 equals 0.05 Bitcoin. This seems small but remember: Bitcoin can move 10% in a day — the position size is appropriate for the volatility.",
        action: "Entry above breakout candle with volatility-adjusted position size",
        rule: "Rule 2: Crypto position sizes must be 5-10x SMALLER than stock positions to account for higher volatility",
        calculation: "Entry: $65,600 | Stop: $63,600 | Target: $72,000\nRisk: $2,000 per BTC | Reward: $6,400 per BTC | RR: 1:3.2\nCapital: $10,000 | 1% Risk: $100\nPosition: $100 ÷ $2,000 = 0.05 BTC\n\nIn INR (approx ₹85/dollar):\nEntry: ₹55.76L | Stop: ₹54.06L\nRisk per BTC: ₹1.7L | Position: 0.05 BTC = ₹8,500 risk",
        chartAction: "mark_entry",
        chartData: { entry: 65600, stop: 63600 },
      },
      {
        id: 4,
        title: "Bitcoin Trade Outcome",
        narration: "Bitcoin rallied from $65,600 to $71,200 — well beyond our $72,000 target. Exit at $71,000. Profit: 0.05 BTC times $5,400 equals $270 — or approximately 22,950 rupees before tax. After 30% India crypto tax: net profit approximately 16,065 rupees. Always calculate tax BEFORE celebrating profits. Crypto trading in India requires meticulous record-keeping — every transaction must be reported in ITR.",
        action: "Exiting at target — full post-tax P&L calculation",
        calculation: "Exit: $71,000 | Entry: $65,600 | Stop: $63,600\nGross profit: 0.05 × $5,400 = $270 = ₹22,950\n30% tax: ₹6,885\nNet profit after tax: ₹16,065\n\n1% TDS already deducted at sale\n\nRecord-keeping required:\n• Date of purchase\n• Date of sale\n• Cost of acquisition\n• Sale proceeds\nReport in ITR Schedule VDA",
        chartAction: "mark_exit",
        chartData: { exit: 71000 },
      },
    ],
  },

  // ── SCENARIO 20: TRADE JOURNAL REVIEW ───────────────────────
  {
    id: "trade-journal-review",
    title: "Trade Journal Review — Post-Trade Analysis",
    subtitle: "How professional traders review, learn, and improve — the missing skill",
    category: "Psychology",
    difficulty: "Beginner",
    duration: "4 min",
    icon: "📔",
    isPro: false,
    instrument: "Portfolio Review",
    timeframe: "Weekly review",
    dataSource: "Demonstration — fictional weekly trade log",
    disclaimer: "Educational demonstration. Not investment advice.",
    candles: CANDLESTICK_CANDLES,
    steps: [
      {
        id: 1,
        title: "Why 99% of Traders Skip This Step",
        narration: "The trade journal is the single most powerful tool for improvement — and the most consistently ignored. After a winning trade, traders feel confident and don't bother reviewing. After a losing trade, traders feel bad and don't want to revisit it. Both reactions are wrong. A winning trade with poor process is dangerous — you got lucky. A losing trade with correct process is fine — you followed your rules. The journal reveals the truth.",
        action: "Opening weekly trade journal — 8 trades this week",
        rule: "Core Principle: You do not learn from outcomes. You learn from reviewing PROCESS quality.",
        calculation: "This Week's Raw P&L:\nTrade 1: +₹4,200 | Trade 2: -₹2,100 | Trade 3: +₹1,800\nTrade 4: -₹3,400 | Trade 5: +₹6,100 | Trade 6: +₹800\nTrade 7: -₹1,200 | Trade 8: +₹2,900\nNet Week: +₹9,100\n\nBut P&L is only half the story...",
      },
      {
        id: 2,
        title: "Grading Each Trade on Process",
        narration: "We grade each trade on 5 criteria — not on profit or loss. Criteria: Was the setup valid? Was position size correct? Was stop placed before entry? Was entry at the planned level? Was exit at the planned level? A trade that made money but violated 3 rules is an F-grade trade. A trade that lost money but followed all 5 rules perfectly is an A-grade trade. Over time, A-grade process produces A-grade results.",
        action: "Grading all 8 trades on 5-criteria scorecard",
        rule: "Rule 1: Grade every trade on PROCESS (1-5 score), not on outcome (profit/loss)",
        calculation: "Process Grades This Week:\nTrade 1: 5/5 ✅ Won ₹4,200 (A)\nTrade 2: 4/5 ✅ Lost ₹2,100 (B) — missed perfect entry\nTrade 3: 5/5 ✅ Won ₹1,800 (A)\nTrade 4: 2/5 ❌ Lost ₹3,400 (F) — NO SETUP, revenge trade\nTrade 5: 5/5 ✅ Won ₹6,100 (A)\nTrade 6: 1/5 ❌ Won ₹800 (F) — random trade, got lucky\nTrade 7: 5/5 ✅ Lost ₹1,200 (A) — good process, stopped out\nTrade 8: 4/5 ✅ Won ₹2,900 (B)\n\nA/B trades: +₹13,000 | F trades: -₹2,600\nConclusion: F trades cost you money even this week",
        checkpoint: {
          question: "Trade 6 made ₹800 profit but had 1/5 process score. Trade 7 lost ₹1,200 but had 5/5 process score. Which trade do you learn from positively?",
          options: [
            "Trade 6 — it made money, so the approach works",
            "Trade 7 — correct process is what matters, the loss was acceptable",
            "Both equally — money and process both matter",
            "Neither — focus on the big winners only",
          ],
          correct: 1,
          explanation: "Trade 7 is the one to replicate — perfect process, unlucky loss. If you repeat this process 100 times, the probabilities will work in your favor. Trade 6 was lucky. If you repeat a 1/5 process trade 100 times, you will lose money overall. Process quality predicts long-term results. Outcome quality is random noise.",
        },
        pause: true,
      },
      {
        id: 3,
        title: "Patterns That Reveal Your Edge",
        narration: "After 3 months of journaling, patterns emerge that are impossible to see trade by trade. Which setups have the highest win rate? What time of day are your worst trades? Do you trade worse after a loss? What is your average risk-reward actually achieved versus planned? This data is your personal edge — or your personal leak. Without the journal, you are flying blind. With it, you become a systematic, improving trader.",
        action: "90-day pattern analysis dashboard",
        rule: "Rule 2: Keep the journal for 90 days before drawing any conclusions. One week is noise.",
        calculation: "90-Day Journal Insights (example):\nBest setup: RSI Divergence — 68% win rate\nWorst time: 9:15–9:30 AM — 28% win rate (stop trading here!)\nWorst trigger: After 2 consecutive losses — win rate drops to 31%\nAvg planned RR: 1:2 | Avg actual RR: 1:1.4 (exiting early!)\nBiggest improvement needed: Hold winners longer\n\nAction items:\n1. No trades in first 15 minutes\n2. Mandatory 30-min break after 2 consecutive losses\n3. Never exit at less than 1:1.5 RR",
      },
      {
        id: 4,
        title: "Your Trading Journal Template",
        narration: "This is the exact template to use for every trade. Date, instrument, setup name, entry price, stop price, target price, actual exit, outcome, and most importantly — the five process criteria scores and written notes on what you observed, felt, and learned. The notes section is where real learning happens. Write: what did you see, what did you feel, and would you take this trade again? Over time, these notes become your personal trading playbook — worth more than any course.",
        action: "Complete trade journal template displayed",
        rule: "Final Rule: The journal is your most valuable trading tool. Fill it in within 30 minutes of every trade close.",
        calculation: "Trade Journal Template:\nDate: _________ | Time: _________\nInstrument: ___________ | Setup: ___________\nEntry: ₹_____ | Stop: ₹_____ | Target: ₹_____\nActual Exit: ₹_____ | P&L: ₹_____\n\nProcess Score (1-5):\nSetup valid?      □1 □2 □3 □4 □5\nSize correct?     □1 □2 □3 □4 □5\nStop before entry?□1 □2 □3 □4 □5\nEntry at plan?    □1 □2 □3 □4 □5\nExit at plan?     □1 □2 □3 □4 □5\nTotal: __/25\n\nNotes: What I saw / felt / learned:\n_________________________________",
      },
    ],
  },
];

// ── SQL entries for all 8 new scenarios ──────────────────────
export const NEW_SCENARIOS_SQL = `
-- Add to trading_theater_sql.sql or run separately

INSERT INTO trading_scenarios
(slug, title, subtitle, category, difficulty, duration_mins, instrument,
 timeframe, data_source, total_steps, total_checkpoints, is_free, is_hindi, xp_reward, order_index)
VALUES
('candlestick-pattern-trade','Candlestick Pattern Trade',
 'Hammer and Engulfing live trade',
 'Price Action','beginner',5,'HDFC Bank','15-minute',
 'Historical Oct 2024',5,1,TRUE,FALSE,50,13),

('vwap-intraday-strategy','VWAP Intraday Strategy',
 'Institutional reference line for high-prob entries',
 'Intraday','intermediate',5,'NIFTY 50','5-minute',
 'Historical Oct 2024',4,1,TRUE,FALSE,75,14),

('short-selling-basics','Short Selling',
 'Profiting from falling markets',
 'Advanced Strategies','intermediate',5,'Nifty IT Futures','Daily',
 'Historical 2024',4,1,TRUE,FALSE,75,15),

('gap-up-gap-down-strategy','Gap Up Gap Down Strategy',
 'Reading and trading the opening gap',
 'Intraday','beginner',4,'NIFTY 50','5-minute',
 'Historical Oct 2024',4,1,TRUE,FALSE,50,16),

('fo-expiry-day-strategy','F&O Expiry Day Strategy',
 'Theta decay and Iron Condor on Thursday',
 'Derivatives','advanced',6,'NIFTY Options','5-minute',
 'Historical Oct 2024',4,1,FALSE,FALSE,100,17),

('stop-loss-hunt-operator-trap','Stop-Loss Hunt',
 'How operators trap retail and how to avoid it',
 'Market Mechanics','intermediate',4,'Mid-cap','5-minute',
 'Educational demo',3,1,TRUE,FALSE,75,18),

('crypto-bitcoin-breakout','Bitcoin Breakout Trade',
 'Technical breakout on BTC with India tax context',
 'Crypto','intermediate',4,'Bitcoin','Daily',
 'Historical 2024',4,1,FALSE,FALSE,75,19),

('trade-journal-review','Trade Journal Review',
 'Post-trade analysis — the missing skill',
 'Psychology','beginner',4,'Portfolio','Weekly',
 'Demonstration',4,1,TRUE,FALSE,50,20)

ON CONFLICT (slug) DO NOTHING;
`;
